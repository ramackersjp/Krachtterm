export function setupCounter(element: HTMLButtonElement): void
